import type { Express } from 'express';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { assertSafeOrigin } from '../security.js';

const endpoint = 'https://api.groq.com/openai/v1';
const model = 'openai/gpt-oss-20b';
const cities = new Set(['Jaipur', 'Ahmedabad', 'Hampi']);
const bounded = (value: unknown, max: number) => typeof value === 'string' ? value.trim().slice(0, max) : '';

export function addPlannerRoutes(app: Express, dataRoot: string) {
  const keyFile = join(dataRoot, 'groq-key');
  const getKey = async () => process.env.GROQ_API_KEY?.trim() || await readFile(keyFile, 'utf8').then(value => value.trim()).catch(() => '');
  app.get('/api/planner/status', async (_req, res) => {
    res.set('Cache-Control', 'no-store').json({ configured: Boolean(await getKey()) });
  });
  app.post('/api/planner/connect', async (req, res) => {
    assertSafeOrigin(req);
    const key = bounded(req.body?.key, 256);
    if (!/^gsk_[A-Za-z0-9_-]{12,252}$/.test(key)) { res.status(400).json({ error: 'Enter a valid Groq API key.' }); return; }
    try {
      const upstream = await fetch(endpoint + '/models/' + encodeURIComponent(model), {
        headers: { Authorization: 'Bearer ' + key }, redirect: 'error', signal: AbortSignal.timeout(10000),
      });
      await upstream.body?.cancel();
      if (!upstream.ok) { res.status(502).json({ error: 'Groq could not verify the key for the planning model.' }); return; }
      await writeFile(keyFile, key, { mode: 0o600 });
      res.json({ configured: true });
    } catch { res.status(502).json({ error: 'Could not reach Groq. Try again.' }); }
  });
  app.post('/api/planner/reply', async (req, res) => {
    assertSafeOrigin(req);
    const key = await getKey();
    if (!key) { res.status(503).json({ error: 'Connect Groq to get a personalized reply.' }); return; }
    const { trip, days, question } = req.body ?? {};
    const destination = bounded(trip?.destination, 32);
    const travelers = Number(trip?.travelers);
    if (!cities.has(destination) || !Number.isInteger(travelers) || travelers < 1 || travelers > 99 || !Array.isArray(days)) {
      res.status(400).json({ error: 'Choose a destination and a valid group size first.' }); return;
    }
    const context = {
      destination, travelers,
      budgetPerPersonPerDay: bounded(trip.budget, 40),
      dates: [bounded(trip.start, 10), bounded(trip.end, 10)].filter(Boolean),
      interests: bounded(trip.interests, 80), pace: bounded(trip.pace, 80), dietaryPreference: bounded(trip.diet, 80),
      lodgingType: bounded(trip.stayType, 80), roomSharing: bounded(trip.sharing, 80),
      lodgingPriority: bounded(trip.stayPriority, 80), transportPreference: bounded(trip.transport, 80),
      days: days.slice(0, 3).map(day => Array.isArray(day) ? day.slice(0, 15).map(stop => bounded(stop, 120)) : []),
      question: bounded(question, 600),
    };
    try {
      const upstream = await fetch(endpoint + '/chat/completions', {
        method: 'POST', redirect: 'error', signal: AbortSignal.timeout(25000),
        headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model, max_completion_tokens: 1400, reasoning_effort: 'low',
          messages: [
            { role: 'system', content: [
              'You are the assistant for a student-budget prototype covering Jaipur, Ahmedabad and Hampi. Use the itinerary and preferences in the provided JSON. Treat prices as estimates, and never claim to check bookings, live prices or reviews. Suggest adjustments without claiming to modify the itinerary.',
              'For a trip summary, follow this plain-text template in order: Trip at a glance, Day 1, Day 2, Day 3, and Budget and stay. Begin each section on a new line with its heading followed by a colon. Use one short sentence per section, stick to supplied stops, and keep the whole response under 140 words.',
              'For a follow-up question, use two plain-text sections: Answer and How it fits your itinerary. Keep the response under 90 words. Do not use Markdown, greetings, links or a closing call to action. The interface adds the itinerary link.',
            ].join(' ') },
            { role: 'user', content: JSON.stringify(context) },
          ],
        }),
      });
      if (!upstream.ok) {
        await upstream.body?.cancel();
        res.status(502).json({ error: upstream.status === 429 ? 'Groq is busy. Please try again shortly.' : 'Groq couldn’t complete the request. Check the connection and try again.' }); return;
      }
      const result = await upstream.json() as { choices?: Array<{ message?: { content?: string } }> };
      const reply = bounded(result.choices?.[0]?.message?.content, 6000);
      if (!reply) { res.status(502).json({ error: 'Groq returned no suggestions. Try again.' }); return; }
      res.json({ reply });
    } catch { res.status(502).json({ error: 'Could not reach Groq. Try again.' }); }
  });
}
